package packets


// PeerStatus : Status of the messages received a given peer
type PeerStatus struct {
	Identifier string
	NextID     uint32
}

